import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.sql.ResultSet;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;


public class palteform extends JDialog {
    private JPanel formulaire;
    private JTextField prenom;
    private JTextField email;
    private JTextField date;
    private JButton ajouterButton;
    private JTextField nom;
    private JButton modifierButton;
    private JButton gerercours;

    private JTextField sp;
    private JTable table1;
    private JScrollPane table_1;
    private JButton supprimerButton;

    private JButton chercher;

    private ArrayList<eleve> eleves = new ArrayList<eleve>();



    public JPanel getpanel() {

        return formulaire;
    }

    public palteform() {
        super();
        table1();


        ajouterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ajouteleve();


            }
        });


        gerercours.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame1 = new JFrame("p");
                getContentPane().add(gerercours, BorderLayout.CENTER);
                frame1.setContentPane(new p2().getpanel());
                frame1.pack();
                frame1.setVisible(true);

            }
        });
        supprimerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimereleve();

            }
        });
        chercher.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cherhcherueleve();            }
        });
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifiereleve();
            }
        });
    }



    private void ajouteleve() {
        String n = nom.getText();
        String p = prenom.getText();
        String e = email.getText();
        String d = date.getText();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        if (n.isEmpty() || p.isEmpty() || e.isEmpty() || d.isEmpty()) {
            JOptionPane.showMessageDialog(this, "remplir tous les champs");

        } else {
            JOptionPane.showMessageDialog(this, "avec succees");
        }
        if (!n.matches("[a-zA-Z' ]{3,}") || !p.matches("[a-zA-Z' ]{3,}")) {
            JOptionPane.showMessageDialog(this, "Le nom et prénom doivent contenir uniquement des lettres et apostrophes, et avoir au moins 3 caractères.");
            return;
        }

        if (!e.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            JOptionPane.showMessageDialog(this, "L'adresse mail n'est pas valide.");
            return;
        }


        try {
            Date dateObj = format.parse(d);
            addeleveToDatabase(n, p, e, dateObj);
            JOptionPane.showMessageDialog(this, "élève ajouter avec succès");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "La date n'est pas valide sous cette forma yyyy-mm-dd");
        }


    }

    private void addeleveToDatabase(String n, String p, String e, Date d) {
        final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO eleve (n, p, e, d) " +
                    "VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, n);
            preparedStatement.setString(2, p);
            preparedStatement.setString(3, e);
            preparedStatement.setDate(4, new java.sql.Date(d.getTime()));

            int addedRows = preparedStatement.executeUpdate();
            if (addedRows > 0) {
                eleve eleve = new eleve();
                eleve.setNom(n);
                eleve.setPrenom(p);
                eleve.setEmail(e);
                eleve.setdate();






            }

            table1();
            stmt.close();
            conn.close();


        } catch (Exception e1) {
            System.out.println("Erreur lors de l'insertion des données : " + e1.getMessage());
        }
    }



    private void table1() {
        try {
            final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

            final String USERNAME = "root";
            final String PASSWORD = "";

            Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM eleve");
            table1.setModel(DbUtils.resultSetToTableModel(rs));






        } catch (SQLException e3) {
            throw new RuntimeException(e3);
        }


    }
    private void supprimereleve() {
        String n = nom.getText();
        String p = prenom.getText();
        String e = email.getText();
        String d = date.getText();

        String spp;
        spp=sp.getText();


        final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            Statement stmt = conn.createStatement();
            String sql = "delete from eleve  " +
                    "where id=?";

            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, spp);
            preparedStatement.executeUpdate();
             {
                 eleve eleve = new eleve();
                 eleve.setNom(n);
                eleve.setPrenom(p);
                eleve.setEmail(e);
                eleve.setdate();
                nom.setText("");
                 prenom.setText("");
                 email.setText("");
                 date.setText("");



                 eleves.remove(eleve);


            }

            JOptionPane.showMessageDialog(this, "élève spprimer avec succès");

            table1();
            stmt.close();
            conn.close();


        } catch (Exception e1) {
            System.out.println("Erreur lors de la supprision des données : " + e1.getMessage());

        }
    }
    private void cherhcherueleve() {
        String n = nom.getText();
    String p = prenom.getText();
    String e = email.getText();
    String d = date.getText();

    String rec;



    final String DB_URL = "jdbc:mysql://localhost:3306/eleves";

    final String USERNAME = "root";
    final String PASSWORD = "";
        try {
            rec=sp.getText();


            Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);


        PreparedStatement stmt = conn.prepareStatement("select n,p,e,d from eleve where id=?");
        stmt.setString(1, rec);
        ResultSet rs=stmt.executeQuery();
            {if (rs.next()== true) {
                String enom = rs.getString(1);
                String eprenom = rs.getString(2);
                String eemail = rs.getString(3);
                String edate = rs.getString(4);
                prenom.setText(enom);
                nom.setText(eprenom);
                email.setText(eemail);
                date.setText(edate);
            }
            else{
                prenom.setText("");
                nom.setText("");
                email.setText("");
                date.setText("");
                JOptionPane.showMessageDialog(null, "aucune resultas");





            }


        }

        table1();
        stmt.close();
        conn.close();


    } catch (Exception e5) {
        System.out.println("Erreur lors de la supprision des données : " + e5.getMessage());

    }

    }
    private void modifiereleve() {
        String n = nom.getText();
        String p = prenom.getText();
        String e = email.getText();
        String d = date.getText();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");



        String rec;
        try {
            Date dateObj = format.parse(d);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "La date n'est pas valide sous cette forma yyyy-mm-dd");
        }

        final String DB_URL = "jdbc:mysql://localhost:3306/eleves";
        final String USERNAME = "root";
        final String PASSWORD = "";
        try {
            Connection conn = (Connection) DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            PreparedStatement stmt = conn.prepareStatement("update eleve set n=?,p=?,e=?,d=?  where id=?");
            Date dateObj = format.parse(d);

            rec = sp.getText();
            stmt.setString(1, n);
            stmt.setString(2, p);
            stmt.setString(3, e);

            stmt.setDate(4, new java.sql.Date(dateObj.getTime()));
            stmt.setString(5, rec);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Mise à jour réussie");
            } else {
                JOptionPane.showMessageDialog(null, "Aucune mise à jour effectuée");

                prenom.setText("");
                nom.setText("");
                email.setText("");
                date.setText("");
            }

            table1();
            stmt.close();
            conn.close();
        } catch (Exception e5) {
            System.out.println("Erreur lors de la mise a jour des données : " + e5.getMessage());
        }
    }





}








