import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class eleve {
    private static int count = 0;
    private String nom;
    private String prenom;
    private String email;
    LocalDate dateOfBirth = null;
    private String idcours;
    private List<String>eleves;

    public eleve(){
        eleves=new ArrayList<>();

    }


    public eleve(String nom, String prenom, String email, Date dateofbirthday,String idcours) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.idcours=idcours;
        eleves=new ArrayList<>();

        List<eleve> listeeleves = new ArrayList<>();
    }

    // Getters et setters pour chaque attribut
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void getLocalDate(){
        return ;
    }

    public void setdate( ) {
        this.dateOfBirth = dateOfBirth;
    }
    public String getIdcours() {
        return idcours;
    }
    public void setIdcours(String idc) {
        this.idcours = idcours;
    }


}