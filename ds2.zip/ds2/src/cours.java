public class cours {
    private String idcours;
    private String nomc;

    public cours(String idcours ,String nomc){



    }






}
